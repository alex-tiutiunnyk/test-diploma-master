import googlemaps
from geopy.distance import geodesic
import folium
from kafka import KafkaConsumer
import pymongo
import json
import time

mongo_client = pymongo.MongoClient("mongodb+srv://dbUser:dbUserPassword@cluster-diploma.o4oil.mongodb.net/gps_tracking")
db = mongo_client["gps_tracking"]
gps_collection = db["gps_data_test"]
print(f"Connected: {gps_collection}")

# Kafka Consumer initialization
consumer = KafkaConsumer(
    'gps-coordinates',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='latest',
    enable_auto_commit=True,
    group_id='gps-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

# Google Maps client initialization
gmaps = googlemaps.Client(key='AIzaSyAU1BT0-8JoGE4T1d4d9vd426NfNj3QN3Y')

# Function to snap GPS points to the nearest roads using Google Maps Roads API
def snap_to_roads(coordinates):
    snapped_coords = gmaps.snap_to_roads(path=coordinates, interpolate=True)
    # print(f"SNAPPED COORDS = {snapped_coords}")
    return [(point['location']['latitude'], point['location']['longitude']) for point in snapped_coords]

# Function to calculate speed between two coordinates in km/h
def calculate_speed_kmph(coords1, coords2, time_diff):
    distance_km = geodesic(coords1, coords2).kilometers
    print(f"Distance in kilometers: {distance_km}")
    time_hours = time_diff / 3600
    return distance_km / time_hours if time_hours > 0 else 0

# Function to update the record with speeds
def update_with_speeds(device_id, timestamp, current_speed, average_speed):
    gps_collection.update_one(
        {'device_id': device_id, 'timestamp': timestamp},
        {'$set': {
            'current_speed': current_speed,
            'average_speed': average_speed
        }}
    )
    print(f"Updated GPS Data for {device_id} at {timestamps[i + 1]} with speeds.")


# Process incoming data and save it to MongoDB
print("Listening for GPS data...")
for message in consumer:
    print(f"Received GPS Data: {message.value}")
    gps_data = message.value
    
    # Get the current data from Kafka
    device_id = gps_data['deviceId']
    lat = gps_data['latitude']
    lon = gps_data['longitude']
    timestamp = gps_data['timestamp']
    
    # Save data to MongoDB
    gps_collection.insert_one(gps_data)
    print(f"Inserted GPS Data: {gps_data}")
    
    # Retrieve all records of the device to calculate trajectory and speed
    device_data = list(gps_collection.find({"deviceId": device_id}).sort("timestamp"))
    
    # Ensure there are enough records for processing
    if len(device_data) > 1:
        # Snap the coordinates to roads
        coordinates = [(entry['latitude'], entry['longitude']) for entry in device_data]
        timestamps = [entry['timestamp'] for entry in device_data]
        
        snapped_coordinates = snap_to_roads(coordinates)
        
        # Truncate timestamps to match the length of snapped coordinates
        if len(timestamps) > len(snapped_coordinates):
            timestamps = timestamps[:len(snapped_coordinates)]

        # Speed calculation and visualization
        # total_speed = 0.0
        # Check that we have enough intervals
        intervals_count = min(len(snapped_coordinates) - 1, len(timestamps) - 1)

        for i in range(intervals_count):
            coords1 = snapped_coordinates[i]
            coords2 = snapped_coordinates[i + 1]
            # Time difference
            time_diff = time.mktime(time.strptime(timestamps[i + 1], '%Y-%m-%dT%H:%M:%S.%f')) - \
                        time.mktime(time.strptime(timestamps[i], '%Y-%m-%dT%H:%M:%S.%f'))

            # Check if the time difference is valid
            if time_diff > 0:
                current_speed = calculate_speed_kmph(coords1, coords2, time_diff)
                # total_speed += current_speed
            else:
                print(f"Invalid time difference between point {i} and {i + 1}")
        
            # Calculate overall average speed
            # overall_average_speed = total_speed / (i + 1) if (i + 1) > 0 else 0

            # Save data with current and average speed to MongoDB
            # update_with_speeds(device_id, timestamps[i + 1], current_speed)
        
        # Map visualization
        mymap = folium.Map(location=snapped_coordinates[0], zoom_start=15)
        
        for coord in snapped_coordinates:
            folium.Marker(coord, tooltip=f"{device_id}").add_to(mymap)
        
        # Save map
        mymap.save(f"{device_id}_trajectory_map.html")
        print(f"Trajectory map saved for device with id='{device_id}'. Current speed: {current_speed:.2f} km/h")
        # print(f"Overall average speed: {overall_average_speed:.2f} km/h")
