from pymongo import MongoClient
from kafka import KafkaConsumer
import json
from datetime import datetime

# Connect to MongoDB
mongo_connection_string = "mongodb+srv://dbUser:dbUserPassword@cluster-diploma.o4oil.mongodb.net/gps_tracking"

# Connect to MongoDB Atlas
client = MongoClient(mongo_connection_string)
db = client['gps_tracking']
gps_collection = db['gps_data']
print(f"Connected: {gps_collection}")

# Kafka Consumer Setup
consumer = KafkaConsumer(
    'gps-coordinates',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='latest',
    enable_auto_commit=True,
    group_id='gps-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

# Function to calculate speed between two GPS points (basic distance/time formula)
def calculate_speed(prev_coord, new_coord, time_diff_seconds):
    from geopy.distance import geodesic

    if prev_coord:
        distance_km = geodesic((prev_coord['latitude'], prev_coord['longitude']),
                               (new_coord['latitude'], new_coord['longitude'])).km
        print(f"distance_km: {distance_km}")
        speed = (distance_km / time_diff_seconds) * 3600  # speed in km/h
        return speed
    return None

# Listen to Kafka and insert GPS data into MongoDB
prev_data = None  # Store previous GPS data for speed calculation

print("Listening for GPS data...")
for message in consumer:
    print(f"Received GPS Data: {message.value}")
    gps_data = message.value

 # Ensure the incoming data has the expected structure
    if 'deviceId' in gps_data and 'latitude' in gps_data and 'longitude' in gps_data and 'timestamp' in gps_data:
        # Create a coordinates dictionary for easier access
        coordinates = {
            'latitude': gps_data['latitude'],
            'longitude': gps_data['longitude']
        }
        gps_data['coordinates'] = coordinates  # Add a coordinates key for consistency

        # Calculate speed if previous data exists
        if prev_data and prev_data["deviceId"] == gps_data["deviceId"]:
            # Adjusted format string to include microseconds
            time_diff = (datetime.strptime(gps_data["timestamp"], "%Y-%m-%dT%H:%M:%S.%f") -
                         datetime.strptime(prev_data["timestamp"], "%Y-%m-%dT%H:%M:%S.%f")).total_seconds()
            gps_data['speed'] = calculate_speed(prev_data['coordinates'], coordinates, time_diff)
        else:
            gps_data['speed'] = None  # No speed calculation for the first data point
    # Insert data into MongoDB
    gps_collection.insert_one(gps_data)
    print(f"Inserted GPS Data: {gps_data}")

    # Update previous data
    prev_data = gps_data