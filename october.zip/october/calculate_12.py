from geopy.distance import geodesic
import datetime

def calculate_speed(prev_coord, new_coord, prev_time, new_time):
    distance = geodesic(prev_coord, new_coord).meters  # Distance in meters
    time_diff = (new_time - prev_time).total_seconds()  # Time difference in seconds
    speed = distance / time_diff  # Speed in meters per second
    return speed
