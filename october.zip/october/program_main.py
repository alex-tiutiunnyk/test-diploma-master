import googlemaps
from geopy.distance import geodesic
from kafka import KafkaConsumer
import pymongo
import json
import time
from datetime import datetime, timedelta

mongo_client = pymongo.MongoClient("mongodb+srv://dbUser:dbUserPassword@cluster-diploma.o4oil.mongodb.net/gps_tracking")
db = mongo_client["gps_tracking"]
gps_collection = db["gps_data_control"]
print(f"Connected: {gps_collection}")

consumer = KafkaConsumer(
    'coordinates-control',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='latest',
    enable_auto_commit=True,
    group_id='gps-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

gmaps = googlemaps.Client(key='AIzaSyAU1BT0-8JoGE4T1d4d9vd426NfNj3QN3Y')

def calculate_speed_kmph(coords1, coords2, time_diff):
    distance_m = geodesic(coords1, coords2).meters
    print(f"Distance in kilometers: {distance_m}")
    return distance_m / time_diff if time_diff > 0 else 0

def predict_future_coordinates(lat, lon, speed_kmph, latest_timestamp):
    max_num_intervals=5
    future_coords = []
    
    speed_kmpm = speed_kmph / 60
    latest_time = datetime.strptime(latest_timestamp, '%Y-%m-%dT%H:%M:%S.%f')

    for i in range(max_num_intervals):
        new_lat = lat + (speed_kmpm / 110.574)
        new_lon = lon + (speed_kmpm / (111.320 * abs(lat)))

        # Snap to the nearest road
        snapped_point = gmaps.snap_to_roads([(new_lat, new_lon)], interpolate=True)
        if snapped_point:
            snapped_lat = snapped_point[0]['location']['latitude']
            snapped_lon = snapped_point[0]['location']['longitude']
        else:
            snapped_lat = new_lat
            snapped_lon = new_lon

        future_time = latest_time + timedelta(minutes=(i + 1))
        future_time_str = future_time.strftime('%Y-%m-%dT%H:%M:%S.%f')

        # Store the coordinate as a dictionary
        future_coords.append({"latitude": snapped_lat, "longitude": snapped_lon, "timestamp": future_time_str})

        lat, lon = snapped_lat, snapped_lon

        nearby_crossroads = gmaps.places_nearby(location=(lat, lon), radius=50, type='intersection')
        if nearby_crossroads['results']:
            print(f"Found crossroads near: {nearby_crossroads['results']}")
            break  # Stop if crossroads found

    return future_coords


print("Listening for GPS data...")
for message in consumer:
    print(f"Received GPS Data: {message.value}")
    gps_data = message.value
    
    device_id = gps_data['deviceId']
    new_lat = gps_data['latitude']
    new_lon = gps_data['longitude']
    new_timestamp = gps_data['timestamp']
    device_type = gps_data['device_type']
    
    latest_record = gps_collection.find_one({"device_id": device_id}, sort=[("timestamp", pymongo.DESCENDING)])
    
    if latest_record:
        # Calculate current speed
        prev_coords = (latest_record['latitude'], latest_record['longitude'])
        new_coords = (new_lat, new_lon)
        time_diff = time.mktime(time.strptime(new_timestamp, '%Y-%m-%dT%H:%M:%S.%f')) - \
                    time.mktime(time.strptime(latest_record['timestamp'], '%Y-%m-%dT%H:%M:%S.%f'))
        
        if time_diff > 0:
            current_speed = calculate_speed_kmph(prev_coords, new_coords, time_diff)
        else:
            print(f"Invalid time difference between the latest record and the new data")
            current_speed = None

        future_coords = predict_future_coordinates(new_lat, new_lon, current_speed, new_timestamp)
    else:
        current_speed = None
        future_coords = None

    new_record = {
        "device_id": device_id,
        "device_type": device_type,
        "latitude": new_lat,
        "longitude": new_lon,
        "timestamp": new_timestamp,
        "current_speed": current_speed,
        "future_coordinates": future_coords
    }

    gps_collection.insert_one(new_record)
    print(f"Inserted GPS Data with speed: {new_record}")
