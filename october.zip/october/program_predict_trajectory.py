import googlemaps
import geopy.distance
import requests
import math
import folium
from shapely.geometry import LineString

API_KEY='AIzaSyAU1BT0-8JoGE4T1d4d9vd426NfNj3QN3Y'
gmaps = googlemaps.Client(key=API_KEY)

def calculate_bearing(lat1, lon1, lat2, lon2):
    snapped_coord1 = snap_to_road(lat1, lon1)
    snapped_coord2 = snap_to_road(lat2, lon2)
    lat1, lon1 = snapped_coord1['latitude'], snapped_coord1['longitude']
    lat2, lon2 = snapped_coord2['latitude'], snapped_coord2['longitude']

    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    dlon = lon2 - lon1
    x = math.sin(dlon) * math.cos(lat2)
    y = math.cos(lat1) * math.sin(lat2) - (math.sin(lat1) * math.cos(lat2) * math.cos(dlon))
    initial_bearing = math.atan2(x, y)
    bearing = (math.degrees(initial_bearing) + 360) % 360
    return bearing

def snap_to_road(lat, lon):
    url = f"https://roads.googleapis.com/v1/snapToRoads?path={lat},{lon}&interpolate=true&key={API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        snapped_data = response.json()
        if 'snappedPoints' in snapped_data:
            snapped_point = snapped_data['snappedPoints'][0]['location']
            return {"latitude": snapped_point['latitude'], "longitude": snapped_point['longitude']}
    return None

def is_crossroad(lat, lon):
    url = f"https://maps.googleapis.com/maps/api/geocode/json?latlng={lat},{lon}&key={API_KEY}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if any(['intersection' in result['types'] for result in data.get('results', [])]):
            return True
    return False

def build_future_trajectory(lat, lon, next_lat, next_lon, speed_ms, num_intervals=5):
    snapped_coord = snap_to_road(lat, lon)
    lat, lon = snapped_coord['latitude'], snapped_coord['longitude']
    future_trajectory = [snapped_coord]
    
    for _ in range(num_intervals):
        # Bearing from current to next point
        bearing = calculate_bearing(lat, lon, next_lat, next_lon)
        # Calculate future point based on distance and bearing
        next_point = geopy.distance.distance(meters=speed_ms).destination((lat, lon), bearing)
        lat, lon = next_lat, next_lon
        next_lat, next_lon = next_point.latitude, next_point.longitude
        
        # Snap to the nearest road
        snapped_coord1 = snap_to_road(lat, lon)
        snapped_coord2 = snap_to_road(next_lat, next_lon)
        lat, lon = snapped_coord1['latitude'], snapped_coord1['longitude']
        next_lat, next_lon = snapped_coord2['latitude'], snapped_coord2['longitude']
        if snapped_coord1:
            future_trajectory.append(snapped_coord1)
            # Check if the point is near a crossroad
            # if check_intersection_on_path(snapped_coord1, snapped_coord2):
            #     print(f"Crossroad detected at {snapped_coord1}. Stopping prediction.")
            #     break
        else:
            print("No snapped coordinate found.")
    
    return future_trajectory

def visualize_trajectories(trajectory1, trajectory2, intersection_point):
    if not trajectory1 or not trajectory2:
        print("One or both trajectories are empty.")
        return
    
    # Initialize map at the starting point of the first trajectory
    initial_location = trajectory1[0]
    mymap = folium.Map(location=[initial_location['latitude'], initial_location['longitude']], zoom_start=15)
    
    # Add markers for trajectory 1 (e.g., Car 1) in red
    for idx, coord in enumerate(trajectory1):
        # Use different colors: first point in red, subsequent points in grey
        color = 'red' if idx == 0 or idx == 1 else 'gray'
        folium.Marker([coord['latitude'], coord['longitude']], 
                      tooltip=f"Car 1, Point {idx + 1}", 
                      icon=folium.Icon(color=color)).add_to(mymap)
    
    # Add markers for trajectory 2 (e.g., Car 2) in blue
    for idx, coord in enumerate(trajectory2):
        color = 'blue' if idx == 0 or idx == 1 else 'gray'
        folium.Marker([coord['latitude'], coord['longitude']], 
                      tooltip=f"Car 2, Point {idx + 1}", 
                      icon=folium.Icon(color=color)).add_to(mymap)

    # Optionally, draw polyline for both trajectories
    folium.PolyLine([(coord['latitude'], coord['longitude']) for coord in trajectory1], 
                    color='red', weight=2.5, opacity=1).add_to(mymap)
    folium.PolyLine([(coord['latitude'], coord['longitude']) for coord in trajectory2], 
                    color='blue', weight=2.5, opacity=1).add_to(mymap)
    
    # Add a pop-up at the intersection point if the lines intersect
    if intersection_point:
        print("I am here")
        folium.Marker(
            [intersection_point.x, intersection_point.y],
            popup=folium.Popup(f"Lines intersect. WARNING", max_width=300),
            icon=folium.Icon(color='green', icon='info-sign')
        ).add_to(mymap)

    # Save the map to an HTML file
    map_file = "colored_trajectories_with_logic.html"
    mymap.save(map_file)
    print(f"Trajectories map saved as {map_file}")

# Example usage
current_lat = 50.448001
current_lon = 30.466309
current_speed = 61.864  # in m/s
next_lat = 50.447577  # For bearing calculation
next_lon = 30.466571

next_lat2 = 50.446818
next_lon2 = 30.467890
current_speed2 = 61.864  # in m/s
current_lat2 = 50.446947  # For bearing calculation
current_lon2 = 30.468572

predicted_trajectory1 = build_future_trajectory(current_lat, current_lon, next_lat, next_lon, current_speed, 5)
predicted_trajectory2 = build_future_trajectory(current_lat2, current_lon2, next_lat2, next_lon2, current_speed2, 3)

line1 = LineString([(predicted_trajectory1[0]['latitude'], predicted_trajectory1[0]['longitude']), (predicted_trajectory1[-1]['latitude'], predicted_trajectory1[-1]['longitude'])])
line2 = LineString([(predicted_trajectory2[0]['latitude'], predicted_trajectory2[0]['longitude']), (predicted_trajectory2[-1]['latitude'], predicted_trajectory2[-1]['longitude'])])
# line2 = LineString([(50.446457, 30.466062), (50.446949, 30.468595)])


# Check if the two lines intersect
if line1.intersects(line2):
    intersection_point = line1.intersection(line2)
    print(f"Lines intersect at {intersection_point}")
    visualize_trajectories(predicted_trajectory1, predicted_trajectory2, intersection_point)
else:
    print("Lines do not intersect")
    visualize_trajectories(predicted_trajectory1, predicted_trajectory2)

print()
print(f"Predicted future trajectory: {predicted_trajectory1}")
print(f"Predicted future trajectory: {predicted_trajectory2}")
print()



# def visualize_trajectory(trajectory, device_id):
#     if not trajectory:
#         print("No trajectory to visualize.")
#         return
    
#     initial_location = trajectory[0]
#     mymap = folium.Map(location=[initial_location['latitude'], initial_location['longitude']], zoom_start=15)
    
#     # Add markers
#     for coord in trajectory:
#         folium.Marker([coord['latitude'], coord['longitude']], tooltip=f"{device_id}").add_to(mymap)
    
#     map_file = f"{device_id}_trajectory____map.html"
#     mymap.save(map_file)
#     print(f"Trajectory map saved for device with id='{device_id}' at {map_file}")
