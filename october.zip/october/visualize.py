import folium
import pymongo

mongo_client = pymongo.MongoClient("mongodb+srv://dbUser:dbUserPassword@cluster-diploma.o4oil.mongodb.net/gps_tracking")
db = mongo_client["gps_tracking"]
gps_collection = db["gps_data_test_2"]
print(f"Connected: {gps_collection}")

# Fetch the latest record of a device, including future coordinates
def get_latest_device_data(device_id):
    latest_record = gps_collection.find({"device_id": device_id}).sort("timestamp", pymongo.DESCENDING).limit(1)
    return list(latest_record)

# Visualize the trajectory on a map
def visualize_trajectory(device_id):
    # Fetch the latest record from MongoDB
    latest_data = get_latest_device_data(device_id)

    if not latest_data:
        print(f"No data found for device ID: {device_id}")
        return

    latest_record = latest_data[0]

    # Extract the current latitude and longitude
    current_lat = latest_record['latitude']
    current_lon = latest_record['longitude']

    # Extract future coordinates if available
    future_coordinates = latest_record.get('future_coordinates', [])
    if not future_coordinates:
        print(f"No future coordinates found for device ID: {device_id}")
        return

    # Combine current coordinates with future coordinates
    all_coordinates = [(current_lat, current_lon)] + [
        (coord['latitude'], coord['longitude']) for coord in future_coordinates
    ]

    print(f"Coordinates (Current + Future): {all_coordinates}")

    # Create a folium map, centered on the current coordinates
    mymap = folium.Map(location=all_coordinates[0], zoom_start=15)

    # Add markers and connect the points to visualize the trajectory
    for i, coord in enumerate(all_coordinates):
        folium.Marker(coord, tooltip=f"Step {i + 1}").add_to(mymap)

    # Draw the lines between the points to represent the trajectory
    folium.PolyLine(all_coordinates, color="blue", weight=2.5, opacity=1).add_to(mymap)

    # Save map as an HTML file
    map_filename = f"{device_id}_visualized_trajectory_map.html"
    mymap.save(map_filename)

    print(f"Trajectory map (current and future) saved for device with id='{device_id}' as {map_filename}")

# Main Function
if __name__ == "__main__":
    # Example device ID for which you want to visualize the latest trajectory
    device_id = 'device-2'  # Replace with your actual device ID
    
    visualize_trajectory(device_id)
