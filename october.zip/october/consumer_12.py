from kafka import KafkaConsumer
import json

# Kafka consumer setup
consumer = KafkaConsumer(
    'gps-coordinates',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='latest',
    enable_auto_commit=True,
    group_id='gps-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

# Consume messages
print("Listening for GPS data...")
for message in consumer:
    print(f"Received GPS Data: {message.value}")
    
# consumer = KafkaConsumer(
#     'gps-coordinates',
#     bootstrap_servers=['localhost:9092'],
#     auto_offset_reset='earliest',
#     enable_auto_commit=True,
#     value_deserializer=lambda x: json.loads(x.decode('utf-8'))
# )

# print("Listening for GPS data...")
# try:
#     while True:
#         for message in consumer:
#             gps_data = message.value
#             print(f"Received GPS Data: {gps_data}")
# except KeyboardInterrupt:
#     print("Stopping consumer...")
