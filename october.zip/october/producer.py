from kafka import KafkaProducer
import json
import time
from datetime import datetime

# Create Kafka producer
producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Array with mock GPS coordinates (lat, lon)
# mock_coordinates = [
#     {"latitude": 37.7749, "longitude": -122.4194},  # San Francisco
#     {"latitude": 34.0522, "longitude": -118.2437},  # Los Angeles
#     {"latitude": 40.7128, "longitude": -74.0060},   # New York
#     {"latitude": 51.5074, "longitude": -0.1278},    # London
#     {"latitude": 48.8566, "longitude": 2.3522},     # Paris
#     {"latitude": 35.6895, "longitude": 139.6917},   # Tokyo
#     {"latitude": 55.7558, "longitude": 37.6173},    # Moscow
#     {"latitude": -33.8688, "longitude": 151.2093},  # Sydney
#     {"latitude": 52.5200, "longitude": 13.4050},    # Berlin
#     {"latitude": 19.4326, "longitude": -99.1332}    # Mexico City
# ]

# mock_coordinates = [
#     {"latitude": 50.4501, "longitude": 30.5234},  # Kyiv center
#     {"latitude": 50.4454, "longitude": 30.5114},  # Near Taras Shevchenko Park
#     {"latitude": 50.4425, "longitude": 30.5113},  # Near Bessarabsky Market
#     {"latitude": 50.4354, "longitude": 30.5154},  # Near Mariinsky Park
#     {"latitude": 50.4265, "longitude": 30.5151},  # Near Pechersk Lavra
#     {"latitude": 50.4290, "longitude": 30.5436},  # Near National Botanical Garden
#     {"latitude": 50.4366, "longitude": 30.5775},  # Outskirts of Kyiv
#     {"latitude": 50.4470, "longitude": 30.5382},  # Returning to the center
#     {"latitude": 50.4542, "longitude": 30.5234},  # Back to Kyiv center
#     {"latitude": 50.4532, "longitude": 30.5200}   # Near Independence Square
# ]

mock_coordinates = [
    {"device_id": "device-1", "device_type": "vehicle", "latitude": 50.447440, "longitude": 30.466622, 'timestamp': '2024-10-13T12:00:00.000'},  
    {"device_id": "device-1", "device_type": "vehicle", "latitude": 50.447957, "longitude": 30.466301, 'timestamp': '2024-10-13T12:00:01.000'},  
    {"device_id": "device-2", "device_type": "vehicle", "latitude": 50.446818, "longitude": 30.467890, 'timestamp': '2024-10-13T12:00:00.000'},  
    {"device_id": "device-2", "device_type": "vehicle", "latitude": 50.446947, "longitude": 30.468572, 'timestamp': '2024-10-13T12:00:01.000'},  
    # {"latitude": 50.450953, "longitude": 30.466775, 'timestamp': '2024-10-13T12:02:00.000'}, 
    # {"latitude": 50.450915, "longitude": 30.467459, 'timestamp': '2024-10-13T12:03:00.000'},
    # {"latitude": 50.449446, "longitude": 30.476404, 'timestamp': '2024-10-13T12:04:00.000'}, 
    # {"latitude": 50.447768, "longitude": 30.486138, 'timestamp': '2024-10-13T12:05:00.000'}, 
    # {"latitude": 50.447001, "longitude": 30.490475, 'timestamp': '2024-10-13T12:06:00.000'},
    # {"latitude": 50.445846, "longitude": 30.493984, 'timestamp': '2024-10-13T12:07:00.000'}, 
    # {"latitude": 50.445204, "longitude": 30.492685, 'timestamp': '2024-10-13T12:08:00.000'}, 
    # {"latitude": 50.444343, "longitude": 30.493437, 'timestamp': '2024-10-13T12:09:00.000'}  
]

def send_gps_data(coordinates):
    for coord in coordinates:
        gps_data = {
            "deviceId": coord["device_id"],
            "device_type": coord["device_type"],
            "latitude": coord["latitude"],
            "longitude": coord["longitude"],
            "timestamp": coord["timestamp"] 
        }
        producer.send('coordinates-control', gps_data)
        print(f"Sent: {gps_data}")
        time.sleep(10)

try:
    send_gps_data(mock_coordinates)
except KeyboardInterrupt:
    producer.close()
    print("Producer stopped.")

# Create a Kafka producer
# producer = KafkaProducer(
#     bootstrap_servers=['localhost:9092'],
#     value_serializer=lambda v: json.dumps(v).encode('utf-8')
# )


# # Function to create mock GPS data
# def send_mock_data(device_id, lat, lon):
#     gps_data = {
#         "deviceId": device_id,
#         "latitude": lat,
#         "longitude": lon,
#         "timestamp": datetime.utcnow().isoformat()
#     }
#     producer.send('gps-coordinates', gps_data)
#     print(f"Sent: {gps_data}")


# # Send mock data every few seconds
# try:
#     while True:
#         send_mock_data("device123", 37.7749, -122.4194)  # San Francisco
#         send_mock_data("device456", 40.7128, -74.0060)   # New York
#         time.sleep(5)  # Send data every 5 seconds
# except KeyboardInterrupt:
#     producer.close()